import { Canvas } from "@react-three/fiber";
import {
  OrbitControls,
  useGLTF,
  useAnimations,
} from "@react-three/drei";
import { useRef, useEffect } from "react";

function Robot() {
  const group = useRef();

  const { scene, animations } = useGLTF("/models/ai-coach.glb");
  scene.traverse((child) => {
  console.log(child.name, child.type);
   });
  const { actions } = useAnimations(animations, group);

  useEffect(() => {
    if (actions) {
      Object.values(actions).forEach((action) => {
        action.reset().fadeIn(0.5).play();
      });
    }
  }, [actions]);

  return (
    <primitive
      ref={group}
      object={scene}
      scale={0.8}
      position={[0, -0.8, 0]}
    />
  );
}

export default function AICoach() {
  return (
    <div className="ai-container">
      <Canvas
        camera={{ position: [0, 1.2, 6], fov: 30 }}
        gl={{ alpha: true }}
        style={{ background: "transparent" }}
      >
        <ambientLight intensity={1.8} />
        <directionalLight position={[5, 5, 5]} intensity={2} />
        <pointLight position={[0, 3, 3]} intensity={2} color="#ff7a00" />

        <Robot />

        <OrbitControls
          enableZoom={false}
          enablePan={false}
          enableRotate={false}
        />
      </Canvas>
    </div>
  );
}